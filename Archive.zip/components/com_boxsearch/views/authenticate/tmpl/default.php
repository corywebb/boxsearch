<?php
echo "authenticate view";