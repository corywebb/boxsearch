DROP TABLE `#__boxsearch_keys` ;
